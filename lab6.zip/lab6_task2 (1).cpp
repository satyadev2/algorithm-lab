#include<bits/stdc++.h>
using namespace std;

 int main()
 {
    int size;
    cout<<"total cakes\n";
    cin>>size;
  cout<<"Enter the calorie values of cakes\n";
  vector<int>calorie(size);
  for(int i=0;i<size;i++)
  {
    int val;
    cin>>val;
    calorie.push_back(val);
  }
  sort(calorie.begin(),calorie.end(), greater<int>());
  for(int i=0;i<size;i++)
  {
    cout<<calorie[i]<<" ";
  }
  int sum=0;
  for(int i=0;i<size;i++)
  {
   sum=sum+(pow(2,i)*calorie[i]);
  }
  cout<<"\nTotal miles marc have to run==\n "<<sum;

 }