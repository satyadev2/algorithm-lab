#include<bits/stdc++.h>
using namespace std; 
int main()
{
int size;
cout<<"total petrol pumps\n";
cin>>size;
vector<int>pro(size);
for(int i=0;i<size;i++)
{
    cin>>pro[i];
}
int capacity;

cout<<"Enter capacity of tank\n";
cin>>capacity;
int temp_cap=capacity;
vector<int>sol;
sort(pro.begin(),pro.end());
for(int i=1;i<size;i++)
{
    if(pro[0]>capacity)
    {
    cout<<"travelling not possible\n";
    break;
    }
    else if(pro[i]-pro[i-1]>capacity)
    {
        cout<<"travelling not possible\n";
        break;
    }
    else if(pro[i]>capacity)
    {
       sol.push_back(pro[i-1]);
       capacity=pro[i-1]+temp_cap;
    }
}
cout<<sol.size();
if(!sol.empty())
{
cout<<"petrol pump on which driver must have to stop on=";
for(auto i:sol)
{
   cout<<i<<"\n";
}
}
}