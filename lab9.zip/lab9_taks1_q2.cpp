#include<bits/stdc++.h>
using namespace std;

int main()
{
    int vertex,edges;
    cin>>vertex>>edges;
    vector<int>adj[vertex]; //vector of arrays corrsponding to all vertex starting from index 1
    for(int i=0;i<edges;i++)
    {
        int v1,v2;
        cin>>v1>>v2;

        //for undirected grah//

        adj[v1].push_back(v2);
        adj[v2].push_back(v1);



    }
    int matrix[vertex][vertex];
    for(int i=0;i<vertex;i++)
    {
        for(int j=0;j<vertex;j++)
        {
            matrix[i][j]=0;
        }
    }
   for(int i=0;i<vertex;i++)
   {
    cout<<i<<"->";
     for(auto j:adj[i])
     {
        cout<<j<<"->";
        matrix[i][j]=1;
     }
       cout<<"null";
     cout<<endl;
   }

   for(int i=0;i<vertex;i++)
    {
        for(int j=0;j<vertex;j++)
        {
            cout<<matrix[i][j]<<" ";
        }
        cout<<endl;
    }
}