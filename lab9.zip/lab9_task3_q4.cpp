
#include <bits/stdc++.h>
using namespace std;

const int N = 1001;
vector <int> graph[N];      // original graph
vector <int> tgraph[N];     // transpose graph
vector <int> tempgraph[N];  // temporary graph for weakly connected components
bool vis[N];

void reset(){
    for(int i=0;i<N;i++)
    vis[i]=false;
}

void dfs1(int vertex){      // on original graph
    vis[vertex]=true;
    for(int child : graph[vertex]){
        if(vis[child])  continue;
        dfs1(child);
    }
}

void dfs2(int vertex){      // on transpose graph
    vis[vertex]=true;
    for(int child : tgraph[vertex]){
        if(vis[child])  continue;
        dfs2(child);
    }
}

void dfs3(int vertex){      // on temp graph
    vis[vertex]=true;
    for(int child : tempgraph[vertex]){
        if(vis[child])  continue;
        dfs3(child);
    }
}

void dfs(int vertex, stack <int> &st){      // on original graph // for topological sort
    vis[vertex]=true;
    for(int child : graph[vertex]){
        if(vis[child])  continue;
        dfs(child, st);
    }
    st.push(vertex);
}

void dfs_strong(int vertex, vector <bool> &visarr){
    visarr[vertex]=true;
    for(int child : graph[vertex]){
        if(visarr[child])  continue;
        dfs_strong(child, visarr);
    }
}

int main(){
    cout<<"Enter number of Vertices and Edges"<<endl;
    int n, m;       // n : number of vertices       m : number of edges
    cin>>n>>m;
    cout<<"Enter all edges : "<<endl;
    
    for(int i=0;i<m;i++){
        int v1, v2;
        cin>>v1>>v2;
        graph[v1].push_back(v2);
        tempgraph[v1].push_back(v2);
        tempgraph[v2].push_back(v1);
    }

    // generating transpose graph of given graph
    for(int i=1;i<=n;i++){
        for(auto element : graph[i]){
            tgraph[element].push_back(i);
        }
    }

    //number of weakly connected components
    reset();
    int weakcount=0;
    for(int i=1;i<=n;i++){
        if(vis[i])  continue;
        dfs3(i);
        weakcount++;
    }
    cout<<"Number of weakly connnected components are : "<<weakcount<<endl;
    int strongcount2=0;     // Number of strongly connected components using transpose graph

    // find number of strongly connected componenets using brute forece
    vector <int> check(n+1, 0);
    vector <vector <int>> scc;
    for(int i=1;i<=n;i++){
        if(check[i]==1)     continue;
        vector <bool> varr(n+1, 0);
        vector <int> temp;
        temp.push_back(i);
        dfs_strong(i, varr);

        for(int j=1;j<=n;j++){
            if(j!=i && varr[j]==1){
                vector <bool> visarr(n+1, 0);
                dfs_strong(j, visarr);
                if(visarr[i]==1){
                    temp.push_back(j);
                }
            }
        }
        for(int k=0;k<temp.size();k++){
            check[temp[k]]=1;
        }
        scc.push_back(temp);
    }

    // displaying strongly connected components
    cout<<"Strongly connected components are : "<<endl;
    for(auto vec : scc){
        for(int element : vec){
            cout<<element<<" ";
        }
        cout<<endl;
    }
    cout<<endl;

    // finding number of strongly connected components using transpose graph
    // topological sort
    stack <int> st;
    reset();
    for(int i=1;i<=n;i++){
        if(vis[i])  continue;
        dfs(i, st);
    }

    reset();
    while(!st.empty()){
        int vertex = st.top();
        st.pop();
        if(vis[vertex])  continue;
        dfs2(vertex);
        strongcount2++;
    }

    cout<<"Number of strongly connected components by brute force : "<<scc.size()<<endl;
    cout<<"Number of strongly connected components by using transverse graph : "<<strongcount2<<endl;
    cout<<"Number of weakly connected components : "<<weakcount<<endl;

    return 0;
}
