#include<bits/stdc++.h>
using namespace std;

struct node
{
    int data;
    struct node *next;
};

int main()
{
   int vertices;
   cout<<"Total vertices\n";
   cin>>vertices;
   vector<node*>satya;
   
     for(int i=0;i<vertices;i++)
    {
       node *t=new node();
       t->data=i;
       t->next=NULL;
       satya.push_back(t);
       int input;
        cin >> input;
       while(input!=-1)
       {
           node *newnode=new node();
           newnode->data=input;
           newnode->next=NULL;
           t->next=newnode;
           t=t->next;
            cin >> input;
       }
    }

   int matrix[vertices][vertices];
   for(int i=0;i<vertices;i++)
   {
    for(int j=0;j<vertices;j++)
    {
        matrix[i][j]=0;
    }
   }

   for(int i=0;i<satya.size();i++)
   {
    node *trav=satya[i]->next;
    while(trav!=NULL)
    {
        matrix[i][trav->data]=1;
        trav=trav->next;
    }
   }
   for(int i=0;i<vertices;i++)
   {
    for(int j=0;j<vertices;j++)
    {
        cout<<matrix[i][j]<<" ";
    }
    cout<<endl;
   }

}