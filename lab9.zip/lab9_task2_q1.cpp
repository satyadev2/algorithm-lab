
#include <bits/stdc++.h>
using namespace std;


int counter=0;

class Graph {
public:
	map<int, list<int> > adj;


	void addEdge(int v, int w);


	void DFS(int v,vector<int>&jd);
};

void Graph::addEdge(int v, int w)
{
	adj[v].push_back(w); 
}

void Graph::DFS(int v,vector<int>&visited)
{	

    if(visited[v])
        return;

	visited[v] = 1;
	cout << v << " ";

	
	list<int>::iterator i;
	for (i = adj[v].begin(); i != adj[v].end(); ++i)
		if (!visited[*i])
			DFS(*i,visited);
}


int main()
{
	Graph g;
    cout<<"total vertices\n";
    int vertices;
    cin>>vertices;
	vector<int> visited(vertices);
    cout<<"total edges\n";
    int edges;
    cin>>edges;
    for(int i=0;i<edges;i++)
    {
        cout<<"Enter vertex number and its neighbour\n";
        int x1,x2;
        cin>>x1>>x2;
         g.addEdge(x1,x2);
         g.addEdge(x2,x1);
    }
//  int flag=0;
	for(int i=0;i<vertices;i++)
    {
        if(!visited[i])
        {
            counter++;
            g.DFS(i,visited);
        }
      
    }
    cout<<"total number of connected components\n"<<counter<<endl;
//  for(auto i:g.adj)
//  {
//     cout<<i.first<<" ";
//  }
}


