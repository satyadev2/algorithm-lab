#include<bits/stdc++.h>
using namespace std;

struct node
{
   int data;
   struct node *next;
};


int main()
{
    int edges;
    cout<<"Total number of edges\n";
    cin>>edges;
    int vertices;
    cout<<"Total number of vertices\n";
    cin>>vertices;
    int matrix[vertices][vertices];
    cout<<"if there exist a edge b/w 2 nodes mark it as 1 else 0"<<endl;
    for(int i=0;i<vertices;i++)
    {
        for(int j=0;j<vertices;j++)
        {
            cin>>matrix[i][j];
            matrix[j][i]=matrix[i][j];
        }
    }
    vector<node*>satya;
    for(int i=0;i<vertices;i++)
    {
       node *t=new node();
       t->data=i;
       t->next=NULL;
       satya.push_back(t);
       for(int j=0;j<vertices;j++)
       {
        if(matrix[i][j]==1)
        {
           node *newnode=new node();
           newnode->data=j;
           newnode->next=NULL;
           t->next=newnode;
           t=t->next;
        }
       }
    }
    for(int i=0;i<vertices;i++)
    {
       node *trav=satya[i];
       while(trav!=NULL)
       {
        cout<<trav->data<<"->";
        trav=trav->next;
       }
       cout<<"NULL"<<endl;
    }
}