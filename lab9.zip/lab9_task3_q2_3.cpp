
#include <bits/stdc++.h>
using namespace std;

const int N = 1001;
vector <int> graph[N];      // original graph
vector <int> tgraph[N];     // transpose graph
vector <int> tempgraph[N];  // temporary graph for weakly connected components
bool vis[N];

void reset(){
    for(int i=0;i<N;i++)
    vis[i]=false;
}

void dfs1(int vertex){      // on original graph
    vis[vertex]=true;
    for(int child : graph[vertex]){
        if(vis[child])  continue;
        dfs1(child);
    }
}

void dfs2(int vertex){      // on transpose graph
    vis[vertex]=true;
    for(int child : tgraph[vertex]){
        if(vis[child])  continue;
        dfs2(child);
    }
}

void dfs3(int vertex){      // on temp graph
    vis[vertex]=true;
    for(int child : tempgraph[vertex]){
        if(vis[child])  continue;
        dfs3(child);
    }
}

int main(){
    cout<<"Enter number of Vertices and Edges"<<endl;
    int n, m;       // n : number of vertices       m : number of edges
    cin>>n>>m;
    cout<<"Enter all edges : "<<endl;
    
    for(int i=0;i<m;i++){
        int v1, v2;
        cin>>v1>>v2;
        graph[v1].push_back(v2);
        tempgraph[v1].push_back(v2);
        tempgraph[v2].push_back(v1);
    }

    // generating transpose graph of given graph
    for(int i=1;i<=n;i++){
        for(auto element : graph[i]){
            tgraph[element].push_back(i);
        }
    }

    // checking if graph is strongly connected or not by brute force
    bool flag = true;
    for(int i=1;i<=n;i++){
        reset();
        dfs1(i);
        for(int i=1;i<=n;i++){
            if(vis[i]==false){
                flag = false;
                break;
            }
        }
        if(flag==false)
        break;
    }
    if(flag){
        cout<<"Graph is strongly connected."<<endl;
    }
    else{
        cout<<"Graph is not strongly connected."<<endl;
    }

    // checking if graph is strongly connected or not by using transpose graph
    bool flag1 = true, flag2=true;
    reset();
    dfs1(1);
    for(int i=1;i<=n;i++){
        if(vis[i]==false){
            flag1 = false;
            break;
        }
    }
    reset();
    dfs2(1);
    for(int i=1;i<=n;i++){
        if(vis[i]==false){
            flag2 = false;
            break;
        }
    }
    if(flag1 && flag2){
        cout<<"Graph is strongly connected."<<endl;
    }
    else{
        cout<<"Graph is not strongly connected."<<endl;
    }

    // checking if graph is weakly connected or not 
    // and number of weakly connected components
  //  cout<<"Checking if graph is weakly connected."<<endl;
    reset();
    int weakcount=0;
    for(int i=1;i<=n;i++){
        if(vis[i])  continue;
        dfs3(i);
        weakcount++;
    }
    if(weakcount==1){
        cout<<"Graph is weakly connected."<<endl;
    }
    else{
        cout<<"Graph is not weakly connected."<<endl;
    }
    return 0;
}


