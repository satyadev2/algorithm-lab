
#include <bits/stdc++.h>
using namespace std;

const int N = 1001;
vector <int> graph[N];      // original graph
vector <int> tgraph[N];     // transpose graph


int main()
{
    cout<<"Enter number of Vertices and Edges"<<endl;
    int n, m;       // n : number of vertices       m : number of edges
    cin>>n>>m;
    cout<<"Enter all edges : "<<endl;
    
    for(int i=0;i<m;i++)
    {
        int v1, v2;
        cin>>v1>>v2;
        graph[v1].push_back(v2);
    }

    // generating transpose graph of given graph
    for(int i=1;i<=n;i++)
    {
        for(auto element : graph[i]){
            tgraph[element].push_back(i);
        }
    }

    // displaying transpose graph
    cout<<"Adjacency List of Transverse Graph : "<<endl;
    for(int i=1;i<=n;i++)
    {
        cout<<i<<" : ";
        for(auto element : tgraph[i])
        {
            cout<<element<<" ";
        }
        cout<<endl;
    }
    cout<<endl;

   
    return 0;
}


