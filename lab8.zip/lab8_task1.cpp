#include<bits/stdc++.h>
using namespace std;

int flag=0;
int ct=0;

void print(vector <vector <int>> &v, int size)
{
  if(flag==1)
  return ;
    for(int i=0;i<size;i++)
    {
        for(int j=0;j<size;j++)
        {
            cout<<v[i][j]<<" "; 
        }
        cout<<endl;
    }
    cout<<endl;
    flag=1;
}

int  safeplace(vector<vector<int>>&chess_board,int row,int col,int size)
{

   for(int i=row,j=col;i>=0;i--)
   {
      if(chess_board[i][j]==1)
      {
        return 0;
      }
   }

   for(int i=row,j=col;i>=0 && col>=0;i--,j--)
   {
      if(chess_board[i][j]==1)
      {
        return 0;
      }
   }
   for(int i=row,j=col;i>=0 && j<size;i--,j++)
   {
      if(chess_board[i][j]==1)
      {
        return 0;
      }
   }
   return 1;
}

void solve(vector<vector<int>>&chess_board,int row,int size)
{
  if(row==size)
  {
      print(chess_board, size);
      ct++;
      
      return ;
  }
  for(int col=0;col<size;col++)
  {
    if(safeplace(chess_board,row,col,size)==1)
    {
       chess_board[row][col]=1;
       solve(chess_board,row+1,size);
       chess_board[row][col]=0;
    }
  }
}


int main()
{
  int size;
  cout<<"size \n";
  cin>>size;
   vector<vector<int>> chess_board(size, vector<int> (size, 0));
  solve(chess_board,0,size);
  cout<<"Total Matrices possible : "<<ct<<endl;
}