#include <bits/stdc++.h>
using namespace std;
int main()
{
  int size;
  cout << "total coins\n";
  cin >> size;
  cout << "Enter the coin values that you have...you must have to give 1 as input\n";
  map<int, int> satya;
  vector<int> coins(size);
  for (int i = 0; i < size; i++)
  {
    int val;
    cin >> val;
    coins.push_back(val);
  }
  sort(coins.begin(), coins.end(), greater<int>());
  for (int i = 0; i < size; i++)
  {
    cout << coins[i] << " ";
  }
  cout << "\ngive the value for which you want minimum number of coins\n";
  int value;
  cin >> value;
  int count = 0;
  while (value != 0)
  {
    for (int i = 0; i < size; i++)
    {
      if (value < coins[i])
      {
        continue;
      }
      else
      {
        value = value - coins[i];
        satya[coins[i]]++;
      }
    }
  }
  for (auto x : satya)
  {
    cout << x.first << " " << x.second << endl;
  }
}