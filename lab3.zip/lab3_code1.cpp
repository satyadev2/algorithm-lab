
#include <bits/stdc++.h>
using namespace std;

bool sort_y(const pair<int, int> &a, const pair<int, int> &b)
{
    return (a.second < b.second);
}
bool sort_x(const pair<int, int> &a, const pair<int, int> &b)
{
    return (a.first < b.first);
}
double distance(pair<double, double> p1, pair<double, double> p2, pair<double, double> &min1, pair<double, double> &min2)
{
    if (sqrt((p1.first - p2.first) * (p1.first - p2.first) + (p1.second - p2.second) * (p1.second - p2.second)) < sqrt((min1.first - min2.first) * (min1.first - min2.first) + (min1.second - min2.second) * (min1.second - min2.second)))
    {
        min1 = p1;
        min2 = p2;
    }
    return sqrt((p1.first - p2.first) * (p1.first - p2.first) + (p1.second - p2.second) * (p1.second - p2.second));
}

double smallest_distance(vector<pair<double, double>> sorted_x, vector<pair<double, double>> sorted_y, pair<double, double> &min1, pair<double, double> &min2)
{

    int n = sorted_x.size();

    if (n <= 1)
    {
        return DBL_MAX;
    }

    pair<double, double> p1, p2, p3, p4 = {DBL_MAX, DBL_MAX};
    vector<pair<double, double>> left_x;
    vector<pair<double, double>> right_x;

    for (int i = 0; i < n; i++)
    {
        if (i < n / 2)
        {
            left_x.push_back(sorted_x[i]);
        }
        else
        {
            right_x.push_back(sorted_x[i]);
        }
    }
    int middle = left_x.back().first;
    vector<pair<double, double>> left_y, right_y;

    for (auto x : sorted_y)
    {
        if (x.first <= middle)
        {
            left_y.push_back(x);
        }
        else
        {
            right_y.push_back(x);
        }
    }

    double d1 = smallest_distance(left_x, left_y, p1, p2);
    double d2 = smallest_distance(right_x, right_y, p3, p4);

    if (d1 < d2)
    {
        min1 = p1;
        min2 = p2;
    }
    else
    {
        min1 = p3;
        min2 = p4;
    }

    double d = min(d1, d2);

    vector<pair<double, double>> split;

    for (auto x : sorted_y)
    {
        if (x.first > middle - d)
            split.push_back(x);
    }

    for (int i = 0; i < split.size(); i++)
    {
        for (int j = i + 1; j < split.size() && split[j].second < split[i].second + d; j++)
        {
            if (distance(split[i], split[j], p1, p2) < d)
            {
                min1 = split[i];
                min2 = split[j];
            
                d = distance(split[i], split[j], p1, p2);
            }
        }
    }

    return d;
}

int main()
{
    int n;
    vector<pair<double, double>> vec;
    cout << "Total points in plane" << endl;
    cin >> n;
    if (n <= 1)
    {
        cout << "Only one point is given as input,so its an invalid input" << endl;
        return 0;
    }

    for (int i = 1; i <= n; i++)
    {
        double x, y;
        cout << "Enter the coordinates of Point " << i << endl;
        cin >> x;
        cin >> y;
        vec.push_back({x, y});
    }
    cout << endl;
    sort(vec.begin(), vec.end(), sort_x);
    vector<pair<double, double>> sorted_x = vec;
    sort(vec.begin(), vec.end(), sort_y);
    vector<pair<double, double>> sorted_y = vec;
    pair<double, double> min1 = {DBL_MAX, DBL_MAX};
    pair<double, double> min2 = {DBL_MAX, DBL_MAX};

    double x = smallest_distance(sorted_x, sorted_y, min1, min2);
    cout<<" **************************************************** "<<endl;
    cout << "\tClosest pair of points are= [" << min1.first << "," << min1.second << "] "
         << " & "
         << "[" << min2.first << "," << min2.second << "] " << endl;
    cout << "*************************************************" << endl;
    cout << "\tDistance : " << x << " units" << endl;

    return 0;
}
