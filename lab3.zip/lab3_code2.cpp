

#include <iostream>
#include <math.h>
#include <float.h>
#include <queue>
using namespace std;
struct Point
{
    int x;
    int y;
};
Point p1, p2;
// typedef pair<float, pair<Point, Point> > pi;
typedef pair<float,pair<int,int> >  pi1;
typedef pair<float,pair<int,int> >  pi2;
priority_queue<pi1, vector<pi1>, greater<pi1> > pq1;
priority_queue<pi1, vector<pi1>, greater<pi1> > pq2;
//   for (int i = 0; i < n; i++)
//     {
//         cout << Px[i].x << " ";
//     }
//     cout << endl;
//     for (int i = 0; i < n; i++)
//     {
//         cout << Py[i].y << " ";
//     }

float dist(Point p1, Point p2)
{
    float distance = sqrt((p1.x - p2.x) * (p1.x - p2.x) +
                          (p1.y - p2.y) * (p1.y - p2.y));


    // pq.push(make_pair(distance,make_pair(p1,p2)));
 
    pq1.push(make_pair(distance,make_pair(p1.x,p1.y)));
    pq2.push(make_pair(distance,make_pair(p2.x,p2.y)));

    // printf("\nClosest Points (%d,%d) and (%d,%d)  %f", p1.x, p1.y, p2.x, p2.y, distance);
    return distance;
}
float bruteForce(Point P[], int n)
{
    float min = FLT_MAX;
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (dist(P[i], P[j]) < min)
            {
                min = dist(P[i], P[j]);
                p1 = P[i];
                p2 = P[j];
            }
    return min;
}

float stripClosest(Point strip[], int size, float d)
{
    float min = d;
    for (int i = 0; i < size; ++i)
        for (int j = i + 1; j < size && (strip[j].y - strip[i].y) < min; ++j)
            if (dist(strip[i], strip[j]) < min)
            {
                min = dist(strip[i], strip[j]);
                p1 = strip[i];
                p2 = strip[j];
            }

    return min;
}

float closestUtil(Point *Px, Point *Py, int n)
{
    if (n <= 3)
        return bruteForce(Px, n);

    int mid = n / 2;
    Point midPoint = Px[mid];
    Point Pyl[mid];
    Point Pyr[n - mid];
    int li = 0, ri = 0;
    for (int i = 0; i < n; i++)
    {
        if ((Py[i].x < midPoint.x || (Py[i].x == midPoint.x && Py[i].y < midPoint.y)) && li < mid)
            Pyl[li++] = Py[i];
        else
            Pyr[ri++] = Py[i];
    }
    float dl = closestUtil(Px, Pyl, mid);
    float dr = closestUtil(Px + mid, Pyr, n - mid);

    float d = min(dl, dr);
    Point strip[n];
    int j = 0;
    for (int i = 0; i < n; i++)
        if (abs(Py[i].x - midPoint.x) < d)
            strip[j] = Py[i], j++;

    return stripClosest(strip, j, d);
}

void Merge(Point *A, Point *L, int leftCount, Point *R, int rightCount, int xORy)
{
    int i, j, k;

    i = 0;
    j = 0;
    k = 0;

    while (i < leftCount && j < rightCount)
    {
        if (xORy == 1)
        {
            if (L[i].x < R[j].x)
                A[k++] = L[i++];
            else
                A[k++] = R[j++];
        }
        else
        {
            if (L[i].y < R[j].y)
                A[k++] = L[i++];
            else
                A[k++] = R[j++];
        }
    }
    while (i < leftCount)
        A[k++] = L[i++];
    while (j < rightCount)
        A[k++] = R[j++];
}

void MergeSort(Point *A, int n, int xORy)
{
    int mid, i;
    Point *L, *R;
    if (n < 2)
        return;

    mid = n / 2;

    L = (Point *)malloc(mid * sizeof(Point));
    R = (Point *)malloc((n - mid) * sizeof(Point));

    for (i = 0; i < mid; i++)
        L[i] = A[i];
    for (i = mid; i < n; i++)
        R[i - mid] = A[i];
    if (xORy == 1)
    {
        MergeSort(L, mid, 1);
        MergeSort(R, n - mid, 1);
        Merge(A, L, mid, R, n - mid, 1);
    }
    else
    {
        MergeSort(L, mid, 2);
        MergeSort(R, n - mid, 2);
        Merge(A, L, mid, R, n - mid, 2);
    }

    free(L);
    free(R);
}

float closest(Point P[], int n)
{
    Point Px[n];
    Point Py[n];
    for (int i = 0; i < n; i++)
    {
        Px[i] = P[i];
        Py[i] = P[i];
    }
    MergeSort(Px, n, 1);
    MergeSort(Py, n, 2);
    return closestUtil(Px, Py, n);
}
int main()
{
    Point P[] = {{1, 1}, {0, 0}, {1, 3}, {5, 1}, {12, 10}, {3, 3}};
    int n = sizeof(P) / sizeof(P[0]);
    cout << "The smallest distance is " << closest(P, n);
    cout << "\nEnter the value of k(number of distances required)";
    int k;
    cin >> k;
    float prevD;
    for (int i = 1,j=1; !pq1.empty(); i++)
    {
        float D = pq1.top().first;
        int p1x = pq1.top().second.first;
        int p1y = pq1.top().second.second;
        int p2x = pq2.top().second.first;
        int p2y = pq2.top().second.second;
if(D!=prevD&&j<=k)
        {printf("\nDistance between Points (%d,%d) and (%d,%d) is %f", p1x, p1y, p2x, p2y,D);
            j++;
        }
            pq1.pop();
            pq2.pop();
            prevD = D;
    }

        return 0;
}


	
	
	
